package edu.niu.cs.z1904619.favouritethings;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tumho_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tumho);
    }//end of onCreate method
}//end of Tumho_Activity