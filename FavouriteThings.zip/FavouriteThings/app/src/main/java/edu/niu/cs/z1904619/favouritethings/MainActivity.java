//Name: Devashri Gaikwad Zid:z1904619
//Name: Varun Naraharisetti Zid:Z1913793


package edu.niu.cs.z1904619.favouritethings;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

import java.util.List;


public class MainActivity extends Activity {
    Button goTo;
    Intent intent;
    Spinner spinner;
    String ListItems;
    String[] List = {
            "Khwabonke Parindey",
            "Remember",
            "Dariya",
            "Tumho",
            "Kyon"
    };//end of List


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView image = (ImageView) findViewById(R.id.imageView);




        spinner =(Spinner)findViewById(R.id.spinner);

        goTo = (Button)findViewById(R.id.button);

        // ArrayAdapter to initialize the adapter and attach the adapter to spinner list

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, List);

        spinner.setAdapter(adapter);

        // setonitemeselectedlistener method for spinner.

        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                ListItems = (String)spinner.getSelectedItem();

                switch (position) {
                    case 0:

                        image.setImageResource(R.drawable.zmnd);
                        break;

                    case 1:

                        image.setImageResource(R.drawable.coco);
                        break;

                    case 2:

                        image.setImageResource(R.drawable.dariya);
                        break;

                    case 3:

                        image.setImageResource(R.drawable.tum);
                        break;

                    case 4:

                        image.setImageResource(R.drawable.k);
                        break;
                }





            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

             //auto generated method
           }//end of onNothing selected
        });// end of setonitemeselectedlistener method




        //set on clicklistener for  button to go to new activity selected


        goTo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                switch(ListItems){

                    case "Khwabonke Parindey":
                        intent = new Intent(MainActivity.this, Khwaboke_Activity.class);
                        startActivity(intent);
                        break;

                    case "Remember":
                        intent = new Intent(MainActivity.this, Remember_Activity.class);
                        startActivity(intent);
                        break;

                    case "Dariya":
                        intent = new Intent(MainActivity.this, Dariya_Activity.class);
                        startActivity(intent);
                        break;

                    case "Tumho":
                        intent = new Intent(MainActivity.this, Tumho_Activity.class);
                        startActivity(intent);
                        break;

                    case "Kyon":
                        intent = new Intent(MainActivity.this, Kyon_Activity.class);
                        startActivity(intent);
                        break;



                }//end of switch case
            }//end of On click method
        });// end of setOnClickListener method

    }//end of oncreate
}// end of main activity
