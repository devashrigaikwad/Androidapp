package edu.niu.cs.z1904619.favouritethings;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Dariya_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dariya);
    }//end of onCreate method
}//end of Dariya_Activity .